import json
import os
import uuid
from datetime import datetime
import boto3

dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

TABLE_NAME = os.environ['TABLE_NAME']
BUCKET_NAME = os.environ['BUCKET_NAME']
table = dynamodb.Table(TABLE_NAME)

def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps(body)
    }

def handler(event, context):
    path = event.get('path', '')
    method = event.get('httpMethod', '')

    # Handle CORS preflight OPTIONS request
    if method == 'OPTIONS':
        return response(200, {"message": "CORS preflight OK"})

    # Extract user attributes from Cognito token authorizer claims
    claims = event.get('requestContext', {}).get('authorizer', {}).get('claims', {})
    user_dept = claims.get('custom:department', 'General')
    user_role = claims.get('custom:role', 'MEMBER')

    # ─────────────────────────────────────────────────────────────────
    # Read-Only Routes (Accessible by all authenticated users)
    # ─────────────────────────────────────────────────────────────────

    # GET /public-feed -> Anyone logged in can view all items marked PUBLIC
    if path == '/public-feed' and method == 'GET':
        try:
            res = table.query(
                IndexName='PublicVisibilityIndex',
                KeyConditionExpression=boto3.dynamodb.conditions.Key('visibility').eq('PUBLIC')
            )
            return response(200, res.get('Items', []))
        except Exception as e:
            return response(500, {"error": str(e)})

    # GET /department/workspace -> Fetch all items for the user's department
    if path == '/department/workspace' and method == 'GET':
        try:
            res = table.query(
                KeyConditionExpression=boto3.dynamodb.conditions.Key('pk').eq(f"DEPT#{user_dept}")
            )
            return response(200, res.get('Items', []))
        except Exception as e:
            return response(500, {"error": str(e)})

    # ─────────────────────────────────────────────────────────────────
    # Protected Management Routes (Require LEAD role)
    # ─────────────────────────────────────────────────────────────────

    if user_role != 'LEAD':
        return response(403, {"error": "Unauthorized: Department Lead role required"})

    body = json.loads(event.get('body', '{}')) if event.get('body') else {}

    # POST /department/interns -> Create an Intern Profile
    if path == '/department/interns' and method == 'POST':
        item_id = str(uuid.uuid4())
        item = {
            "pk": f"DEPT#{user_dept}",
            "sk": f"INTERN#{item_id}",
            "id": item_id,
            "type": "PROFILE",
            "name": body.get("name", ""),
            "role": body.get("role", ""),
            "institution": body.get("institution", ""),
            "department": user_dept,
            "visibility": body.get("visibility", "PRIVATE"),
            "created_at": datetime.utcnow().isoformat()
        }
        try:
            table.put_item(Item=item)
            return response(201, item)
        except Exception as e:
            return response(500, {"error": str(e)})

    # POST /department/photos -> Generate Presigned S3 Upload URL & Save Metadata
    if path == '/department/photos' and method == 'POST':
        file_name = f"{user_dept}/{int(datetime.utcnow().timestamp())}_{body.get('fileName')}"
        
        try:
            upload_url = s3_client.generate_presigned_url(
                'put_object',
                Params={
                    'Bucket': BUCKET_NAME,
                    'Key': file_name,
                    'ContentType': body.get('fileType', 'image/jpeg')
                },
                ExpiresIn=3600
            )

            item_id = str(uuid.uuid4())
            item = {
                "pk": f"DEPT#{user_dept}",
                "sk": f"PHOTO#{item_id}",
                "id": item_id,
                "type": "PHOTO",
                "imageUrl": f"https://{BUCKET_NAME}.s3.amazonaws.com/{file_name}",
                "caption": body.get("caption", ""),
                "department": user_dept,
                "visibility": body.get("visibility", "PRIVATE"),
                "created_at": datetime.utcnow().isoformat()
            }
            table.put_item(Item=item)
            return response(200, {"uploadUrl": upload_url, "item": item})
        except Exception as e:
            return response(500, {"error": str(e)})

    # PUT /department/items -> Edit Profile Details or Photo Captions
    if path == '/department/items' and method == 'PUT':
        item_sk = body.get("sk")
        if not item_sk:
            return response(400, {"error": "Missing sort key (sk)"})

        try:
            if "PHOTO" in item_sk:
                table.update_item(
                    Key={"pk": f"DEPT#{user_dept}", "sk": item_sk},
                    UpdateExpression="SET caption = :c",
                    ExpressionAttributeValues={":c": body.get("caption", "")}
                )
            else:
                table.update_item(
                    Key={"pk": f"DEPT#{user_dept}", "sk": item_sk},
                    UpdateExpression="SET #n = :n, #r = :r, institution = :i",
                    ExpressionAttributeNames={"#n": "name", "#r": "role"},
                    ExpressionAttributeValues={
                        ":n": body.get("name", ""),
                        ":r": body.get("role", ""),
                        ":i": body.get("institution", "")
                    }
                )
            return response(200, {"message": "Item updated successfully"})
        except Exception as e:
            return response(500, {"error": str(e)})

    # DELETE /department/items -> Remove an Item
    if path == '/department/items' and method == 'DELETE':
        item_sk = body.get("sk")
        if not item_sk:
            return response(400, {"error": "Missing sort key (sk)"})

        try:
            table.delete_item(Key={"pk": f"DEPT#{user_dept}", "sk": item_sk})
            return response(200, {"message": "Item deleted successfully"})
        except Exception as e:
            return response(500, {"error": str(e)})

    # PUT /department/visibility -> Toggle between PUBLIC and PRIVATE
    if path == '/department/visibility' and method == 'PUT':
        item_sk = body.get("sk")
        new_vis = body.get("visibility")

        if not item_sk or not new_vis:
            return response(400, {"error": "Missing sk or visibility value"})

        try:
            table.update_item(
                Key={"pk": f"DEPT#{user_dept}", "sk": item_sk},
                UpdateExpression="SET visibility = :v",
                ExpressionAttributeValues={":v": new_vis}
            )
            return response(200, {"message": "Visibility updated", "visibility": new_vis})
        except Exception as e:
            return response(500, {"error": str(e)})

    return response(404, {"error": "Route not found"})