import json
import os
import uuid
import boto3

# Connect to AWS Resources
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ["TABLE_NAME"])

s3 = boto3.client('s3')
BUCKET_NAME = os.environ["BUCKET_NAME"]

def handler(event, context):
    """
    Main entry point for the Lambda function.
    Routes operations based on HTTP method and API Gateway resource path.
    """
    http_method = event.get("httpMethod")
    path = event.get("resource", "")

    try:
        if http_method == "GET" and path == "/interns":
            return get_all_interns()
        elif http_method == "GET" and path == "/interns/{id}":
            intern_id = event["pathParameters"]["id"]
            return get_intern(intern_id)
        elif http_method == "POST" and path == "/interns":
            body = json.loads(event.get("body", "{}"))
            return create_intern(body)
        elif http_method == "PUT" and path == "/interns/{id}":
            intern_id = event["pathParameters"]["id"]
            body = json.loads(event.get("body", "{}"))
            return update_intern(intern_id, body)
        elif http_method == "DELETE" and path == "/interns/{id}":
            intern_id = event["pathParameters"]["id"]
            return delete_intern(intern_id)
        elif http_method == "POST" and path == "/presigned-url":
            body = json.loads(event.get("body", "{}"))
            return generate_presigned_url(body)
        
        return api_response(400, {"error": "Unsupported route"})

    except Exception as e:
        return api_response(500, {"error": str(e)})

def get_all_interns():
    """Scan the table and return all intern records."""
    result = table.scan()
    return api_response(200, result.get("Items", []))

def get_intern(intern_id):
    """Fetch a single intern by intern_id."""
    result = table.get_item(Key={"intern_id": intern_id})
    if "Item" not in result:
        return api_response(404, {"error": f"Intern {intern_id} not found"})
    return api_response(200, result["Item"])

def create_intern(body):
    """Create a new intern profile with auto-generated UUID."""
    item = {
        "intern_id": str(uuid.uuid4()),
        "name": body.get("name", ""),
        "field": body.get("field", ""),
        "school": body.get("school", ""),
        "imageUrl": body.get("imageUrl", "")
    }
    table.put_item(Item=item)
    return api_response(201, item)

def update_intern(intern_id, body):
    """Update an existing intern's fields in DynamoDB."""
    result = table.update_item(
        Key={"intern_id": intern_id},
        UpdateExpression="SET #n = :n, #f = :f, school = :s, imageUrl = :img",
        ExpressionAttributeNames={
            "#n": "name",   # "name" is a reserved keyword in DynamoDB
            "#f": "field"
        },
        ExpressionAttributeValues={
            ":n": body.get("name", ""),
            ":f": body.get("field", ""),
            ":s": body.get("school", ""),
            ":img": body.get("imageUrl", "")
        },
        ReturnValues="ALL_NEW"
    )
    return api_response(200, result.get("Attributes", {}))

def delete_intern(intern_id):
    """Delete an intern profile by intern_id."""
    table.delete_item(Key={"intern_id": intern_id})
    return api_response(200, {"message": f"Deleted intern {intern_id}"})

def generate_presigned_url(body):
    """Generate an S3 presigned PUT URL for direct browser image uploads."""
    file_name = body.get("fileName", "")
    file_type = body.get("fileType", "image/jpeg")
    
    key = f"profiles/{file_name}"
    
    presigned_url = s3.generate_presigned_url(
        "put_object",
        Params={
            "Bucket": BUCKET_NAME,
            "Key": key,
            "ContentType": file_type
        },
        ExpiresIn=3600
    )
    
    public_image_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{key}"
    
    return api_response(200, {
        "uploadUrl": presigned_url,
        "imageUrl": public_image_url
    })

def api_response(status_code, body):
    """Build response dictionary expected by API Gateway proxy integration."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization"
        },
        "body": json.dumps(body, default=str)
    }