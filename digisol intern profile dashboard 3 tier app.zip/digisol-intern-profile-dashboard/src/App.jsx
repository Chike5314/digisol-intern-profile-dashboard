import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { BrowserRouter } from "react-router-dom";
import { ToastProvider } from "./components/ui/ToastProvider";
import { DashboardContent } from "./components/DashboardContent";
import { signInWithRedirect } from 'aws-amplify/auth';

// eslint-disable-next-line react-refresh/only-export-components -- withAuthenticator is a HOC; fast refresh can't trace through it
function App({ signOut }) {
  return (
    <ToastProvider>
      <BrowserRouter>
        <DashboardContent signOut={signOut} />
      </BrowserRouter>
    </ToastProvider>
  );
}

export default withAuthenticator(App, {
signUpAttributes: ["email"],
  formFields: {
    signUp: {
      "custom:department": {
        order: 1,
        placeholder: "Enter Department Name (e.g. SoftwareEngineering)",
        label: "Department Name",
        isRequired: true,
      },
      "custom:role": {
        order: 2,
        placeholder: "Role (LEAD or MEMBER)",
        label: "Role",
        isRequired: true,
      },
    },
  },
  components: {
    Header() {
      return (
        <div className="p-4 text-center">
          <h2 className="text-xl font-bold text-slate-800">Digisol Dashboard</h2>
          <p className="text-xs text-slate-500 mt-1">Sign in with your workspace account</p>
        </div>
      );
    },
    Footer() {
      return (
        <div className="px-6 pb-6 pt-2">
          <button
            onClick={() => signInWithRedirect({ provider: 'Google' })}
            className="w-full flex items-center justify-center gap-3 bg-white border border-slate-300 text-slate-700 rounded-xl py-2.5 font-semibold text-sm hover:bg-slate-50 transition shadow-sm"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            Sign in with Google
          </button>
        </div>
      );
    },
  },
});
