import json
import os
import uuid
from datetime import datetime
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

TABLE_NAME = os.environ.get('TABLE_NAME')
BUCKET_NAME = os.environ.get('BUCKET_NAME')
table = dynamodb.Table(TABLE_NAME)

def get_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps(body)
    }

def handler(event, context):
    path = event.get('path', '')
    http_method = event.get('httpMethod', '')

    # Preflight OPTIONS request
    if http_method == 'OPTIONS':
        return get_response(200, {"message": "CORS preflight OK"})

    # Extract user identity & department claim from Cognito JWT Claims
    claims = event.get('requestContext', {}).get('authorizer', {}).get('claims', {})
    department = claims.get('custom:department', 'General')
    user_id = claims.get('sub', 'anonymous')

    try:
        # ─────────────────────────────────────────────────────────────
        # Multi-Tenant Photo Gallery Routes
        # ─────────────────────────────────────────────────────────────

        # GET /photos/public -> Fetch all general public photos
        if path.endswith('/photos/public') and http_method == 'GET':
            res = table.query(
                IndexName='VisibilityIndex',
                KeyConditionExpression=Key('visibility').eq('PUBLIC')
            )
            return get_response(200, res.get('Items', []))

        # GET /photos/department -> Fetch photos for user's department
        if path.endswith('/photos/department') and http_method == 'GET':
            res = table.scan(
                FilterExpression=Key('department').eq(department)
            )
            return get_response(200, res.get('Items', []))

        # POST /photos/department -> Generate presigned URL to upload private department photo
        if path.endswith('/photos/department') and http_method == 'POST':
            body = json.loads(event.get('body', '{}'))
            file_name = body.get('fileName', f"{uuid.uuid4()}.jpg")
            file_type = body.get('fileType', 'image/jpeg')

            s3_key = f"departments/{department}/{uuid.uuid4()}_{file_name}"
            presigned_url = s3.generate_presigned_url(
                'put_object',
                Params={'Bucket': BUCKET_NAME, 'Key': s3_key, 'ContentType': file_type},
                ExpiresIn=300
            )

            photo_id = str(uuid.uuid4())
            image_url = f"https://{BUCKET_NAME}.s3.amazonaws.com/{s3_key}"

            # Save metadata to DynamoDB (default visibility is PRIVATE)
            table.put_item(Item={
                'intern_id': photo_id,  # Primary key compatibility
                'photo_id': photo_id,
                'department': department,
                'visibility': 'PRIVATE',
                'image_url': image_url,
                'uploaded_by': user_id,
                'created_at': datetime.utcnow().isoformat()
            })

            return get_response(200, {
                "uploadUrl": presigned_url,
                "photoId": photo_id,
                "imageUrl": image_url
            })

        # PUT /photos/{id}/publish -> Publish department photo to public gallery
        if '/publish' in path and http_method == 'PUT':
            path_params = event.get('pathParameters') or {}
            photo_id = path_params.get('id')
            
            table.update_item(
                Key={'intern_id': photo_id},
                UpdateExpression="SET visibility = :v",
                ExpressionAttributeValues={':v': 'PUBLIC'}
            )
            return get_response(200, {"message": "Photo published to general gallery successfully"})

        return get_response(404, {"error": "Endpoint not found"})

    except Exception as e:
        return get_response(500, {"error": str(e)})