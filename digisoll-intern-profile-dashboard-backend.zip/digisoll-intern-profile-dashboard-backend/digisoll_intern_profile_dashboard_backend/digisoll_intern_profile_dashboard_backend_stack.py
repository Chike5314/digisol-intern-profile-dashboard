from aws_cdk import (
    Stack,
    CfnOutput,
    RemovalPolicy,
    aws_dynamodb as dynamodb,
    aws_s3 as s3,
    aws_lambda as _lambda,
    aws_apigateway as apigw,
    aws_cognito as cognito,
)
from constructs import Construct

# Maintain your original class name so CDK updates the existing deployment
class DigisollInternProfileDashboardBackendStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # 1. DynamoDB Table for Intern Profiles & Gallery Items
        interns_table = dynamodb.Table(
            self, "InternsTable",
            partition_key=dynamodb.Attribute(
                name="intern_id",
                type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
            removal_policy=RemovalPolicy.DESTROY
        )

        # GSI for general public photo queries
        interns_table.add_global_secondary_index(
            index_name="VisibilityIndex",
            partition_key=dynamodb.Attribute(name="visibility", type=dynamodb.AttributeType.STRING),
            sort_key=dynamodb.Attribute(name="created_at", type=dynamodb.AttributeType.STRING)
        )

        # 2. S3 Bucket for Uploads
        image_bucket = s3.Bucket(
            self, "InternImagesBucket",
            block_public_access=s3.BlockPublicAccess(
                block_public_acls=True,
                ignore_public_acls=True,
                block_public_policy=False,
                restrict_public_buckets=False
            ),
            public_read_access=True,
            cors=[s3.CorsRule(
                allowed_methods=[
                    s3.HttpMethods.GET,
                    s3.HttpMethods.PUT,
                    s3.HttpMethods.POST,
                    s3.HttpMethods.DELETE
                ],
                allowed_origins=["*"],
                allowed_headers=["*"]
            )],
            removal_policy=RemovalPolicy.DESTROY,
            auto_delete_objects=True
        )

        # 3. Cognito User Pool & App Client
        user_pool = cognito.UserPool(
            self, "DigisolUserPool",
            user_pool_name="digisol-interns-user-pool",
            self_sign_up_enabled=True,
            sign_in_aliases=cognito.SignInAliases(email=True),
            auto_verify=cognito.AutoVerifiedAttrs(email=True),
            removal_policy=RemovalPolicy.DESTROY
        )

        user_pool_client = user_pool.add_client(
            "DigisolUserPoolClient",
            user_pool_client_name="digisol-interns-web-client",
            generate_secret=False
        )

        # 4. Lambda Function
        crud_lambda = _lambda.Function(
            self, "InternCrudHandler",
            runtime=_lambda.Runtime.PYTHON_3_11,
            handler="handler.handler",
            code=_lambda.Code.from_asset("lambda"),
            environment={
                "TABLE_NAME": interns_table.table_name,
                "BUCKET_NAME": image_bucket.bucket_name
            }
        )

        interns_table.grant_read_write_data(crud_lambda)
        image_bucket.grant_read_write(crud_lambda)

        # 5. REST API Gateway
        api = apigw.RestApi(
            self, "DigisolInternApi",
            rest_api_name="Digisol Intern Service",
            default_cors_preflight_options=apigw.CorsOptions(
                allow_origins=apigw.Cors.ALL_ORIGINS,
                allow_methods=apigw.Cors.ALL_METHODS,
                allow_headers=[
                    "Content-Type",
                    "Authorization",
                    "X-Amz-Date",
                    "X-Api-Key",
                    "X-Amz-Security-Token"
                ]
            )
        )

        authorizer = apigw.CognitoUserPoolsAuthorizer(
            self, "DigisolCognitoAuthorizer",
            cognito_user_pools=[user_pool]
        )

        auth_options = {
            "authorizer": authorizer,
            "authorization_type": apigw.AuthorizationType.COGNITO
        }

        lambda_integration = apigw.LambdaIntegration(crud_lambda)

        # Endpoints
        photos = api.root.add_resource("photos")
        
        public_feed = photos.add_resource("public")
        public_feed.add_method("GET", lambda_integration, **auth_options)

        dept_feed = photos.add_resource("department")
        dept_feed.add_method("GET", lambda_integration, **auth_options)
        dept_feed.add_method("POST", lambda_integration, **auth_options)

        photo_item = photos.add_resource("{id}")
        publish_item = photo_item.add_resource("publish")
        publish_item.add_method("PUT", lambda_integration, **auth_options)

        # CloudFormation Outputs
        CfnOutput(self, "ApiEndpointUrl", value=api.url)
        CfnOutput(self, "UserPoolId", value=user_pool.user_pool_id)
        CfnOutput(self, "UserPoolClientId", value=user_pool_client.user_pool_client_id)